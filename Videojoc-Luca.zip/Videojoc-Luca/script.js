let vida = 100
let pocio = 20
let RaboMayans = 50 
let cremat= false
let veneno= false

function atac(){
    let torn = Math.floor(Math.random()*3)
    if(torn==0){
        atacEnemic("Atac Basic");
    }else if(torn==1){
        atacEnemic("Corrida de lemur");
    }else if(torn==2){
        atacEnemic("Tornado de fuego");
    }
}

function antiQuemaduras(){
    cremat= false
    console.log("Has estat curat de la cremada")
    console.log("La teva vida és:"+vida)
}
function escudoAntisemen(){
    veneno= false
    console.log("Has estat curat del verí")
    console.log("La teva vida és:"+vida)
}

function mostraVida(){
    console.log("La teva vida és:"+vida)
}
function atacEnemic(atac){
  if(vida<=0){
    console.log("Estas mort")
    console.log("La teva vida és:"+vida)
        }else{
            if(atac=="Atac Basic"){
                dany=10
        
            }
            if(atac=="Corrida de lemur"){
                dany=10
                veneno=true
            }
            if(atac=="Tornado de fuego"){
                dany=10
                cremat=true
            }
            vida -= dany 
            if(cremat){
                 vida -=5
            }
            if(veneno){
                vida-=8
            }


            console.log("Has sigut atacat per "+atac)
    console.log("La teva vida és:"+vida)
        }
    
}
function pocionDeVida(){
    if(vida>=100){
        console.log("No té efecte")
console.log("La teva vida és:"+vida)
    }else if(vida>=0){
        vida += pocio
        console.log("Has sigut curat")
console.log("La teva vida és:"+vida)
    }else if(vida==0){
        console.log("No té efecte, estas mort")
console.log("La teva vida és:"+vida)
    }

}
function raboMayans(){
    if(vida==0){
        vida += RaboMayans
        console.log("Has reçucitat")
        console.log("La teva vida és:"+vida)
    }else{
        console.log("Com t'agrada lo que te encanta")
    }
}